built from the bbmodels by tools/convert.py and tools/rig.py
